package com.seleniumexpress.Menu;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Model {
	public static List<IceCream> getList() throws ClassNotFoundException, SQLException
	{
		//connect to postgreSQL database
		String url = "jdbc:postgresql://localhost:5432/menu";
		String username = "postgres";
		String password = "1234";
		String query = "select * from items";
		
		//update the data
		String query_update = "Insert into Items values(7,'Grapes',100.0)";
		
		ArrayList<IceCream> icecream = new ArrayList<>();
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection(url, username, password);	
		Statement stmt = conn.createStatement();
		//System.out.println("Connection = " + stmt.isClosed());
		
		stmt.executeUpdate(query_update);
		
		//fetching data from the database
		ResultSet rs = stmt.executeQuery(query);
		while(rs.next())
		{
			//System.out.println(rs.getString(2));
			int id = rs.getInt("id");
			String item = rs.getString("name");
			float price = rs.getFloat("price");
			IceCream f = new IceCream(id, item, price);
			icecream.add(f);
		}
		return icecream;
	}
	
}
